const publicData = { departments: [], sections: [], faculty: [], periods: [], timetable: [] };

document.addEventListener('DOMContentLoaded', loadPublicTimetable);

let viewerType = 'student';

async function loadPublicTimetable() {
    const response = await fetch('/api/public-timetable');
    if (!response.ok) return;
    Object.assign(publicData, await response.json());
    populatePublicFilters();
    renderPublicTimetable();
}

function populatePublicFilters() {
    const departmentSelect = document.getElementById('filter-dept');
    const sectionSelect = document.getElementById('filter-section');
    departmentSelect.innerHTML = '<option value="">Select department</option>' + publicData.departments.map(item => `<option value="${item.id}">${item.name}</option>`).join('');
    document.getElementById('filter-faculty').innerHTML = '<option value="">Select faculty</option>' + publicData.faculty.map(item => `<option value="${item.id}">${item.name}</option>`).join('');
    departmentSelect.addEventListener('change', () => {
        const departmentId = departmentSelect.value;
        const sections = publicData.sections.filter(item => item.department_id == departmentId);
        sectionSelect.disabled = !departmentId;
        sectionSelect.innerHTML = departmentId
            ? '<option value="">Select batch / section</option>' + sections.map(item => `<option value="${item.id}">${item.name}</option>`).join('')
            : '<option value="">Select department first</option>';
        renderPublicTimetable();
    });
    sectionSelect.addEventListener('change', renderPublicTimetable);
    document.getElementById('filter-faculty').addEventListener('change', renderPublicTimetable);
    document.getElementById('student-choice').addEventListener('click', () => setViewerType('student'));
    document.getElementById('faculty-choice').addEventListener('click', () => setViewerType('faculty'));
}

function setViewerType(type) {
    viewerType = type;
    document.getElementById('student-choice').classList.toggle('active', type === 'student');
    document.getElementById('faculty-choice').classList.toggle('active', type === 'faculty');
    document.querySelector('.student-filters').classList.toggle('hidden', type !== 'student');
    document.querySelector('.faculty-filters').classList.toggle('hidden', type !== 'faculty');
    renderPublicTimetable();
}

function renderPublicTimetable() {
    const departmentId = document.getElementById('filter-dept').value;
    const sectionId = document.getElementById('filter-section').value;
    const facultyId = document.getElementById('filter-faculty').value;
    const filtered = publicData.timetable.filter(item => viewerType === 'student'
        ? (sectionId && item.section_id == sectionId && item.department_id == departmentId)
        : (facultyId && item.faculty_id == facultyId));
    const slots = [...new Set(publicData.periods.map(item => item.time_slot))];
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
    const hasSelection = viewerType === 'student' ? sectionId : facultyId;
    document.getElementById('result-count').textContent = hasSelection ? `${filtered.length} published classes` : 'Select an option to view the timetable';
    document.getElementById('timetable-matrix-body').innerHTML = slots.map(slot => `<tr><td><strong>${slot}</strong></td>${days.map(day => {
        const matches = filtered.filter(item => item.day === day && item.time_slot === slot);
        return `<td>${matches.length ? matches.map(item => `<div class="cell-card"><strong>${item.subject_name}</strong><br>${item.faculty_name}<br>${item.classroom_name}<br>${item.section_name}</div>`).join('') : '<span class="free-slot">Free</span>'}</td>`;
    }).join('')}</tr>`).join('');
}