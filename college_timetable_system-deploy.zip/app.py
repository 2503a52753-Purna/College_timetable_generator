from flask import Flask, render_template, request, jsonify, session, redirect, url_for
from flask_cors import CORS
import sqlite3
import random
import os
from functools import wraps
from pathlib import Path
from werkzeug.security import check_password_hash

app = Flask(__name__)
CORS(app)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or os.urandom(32)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('SESSION_COOKIE_SECURE', '0') == '1'
DB_NAME = Path(__file__).resolve().parent / 'database.db'

def admin_required(view):
    @wraps(view)
    def wrapped_view(*args, **kwargs):
        if not session.get('is_admin'):
            if request.path.startswith('/api/'):
                return jsonify({'status': 'error', 'message': 'Admin authentication required.'}), 401
            return redirect(url_for('admin_login', next=request.path))
        return view(*args, **kwargs)
    return wrapped_view

def get_db():
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.executescript('''
            CREATE TABLE IF NOT EXISTS departments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sections (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                department_id INTEGER,
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            CREATE TABLE IF NOT EXISTS subjects (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                department_id INTEGER,
                hours_per_week INTEGER NOT NULL,
                is_lab INTEGER DEFAULT 0,
                FOREIGN KEY(department_id) REFERENCES departments(id)
            );
            CREATE TABLE IF NOT EXISTS faculty (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                department_id INTEGER,
                subject_id INTEGER,
                availability TEXT,
                FOREIGN KEY(department_id) REFERENCES departments(id),
                FOREIGN KEY(subject_id) REFERENCES subjects(id)
            );
            CREATE TABLE IF NOT EXISTS classrooms (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                is_lab INTEGER DEFAULT 0,
                capacity INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS periods (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                day TEXT NOT NULL,
                time_slot TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS timetable (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                section_id INTEGER,
                subject_id INTEGER,
                faculty_id INTEGER,
                classroom_id INTEGER,
                period_id INTEGER,
                FOREIGN KEY(section_id) REFERENCES sections(id),
                FOREIGN KEY(subject_id) REFERENCES subjects(id),
                FOREIGN KEY(faculty_id) REFERENCES faculty(id),
                FOREIGN KEY(classroom_id) REFERENCES classrooms(id),
                FOREIGN KEY(period_id) REFERENCES periods(id)
            );
        ''')
        faculty_columns = {row['name'] for row in conn.execute('PRAGMA table_info(faculty)')}
        if 'subject_id' not in faculty_columns:
            conn.execute('ALTER TABLE faculty ADD COLUMN subject_id INTEGER')
            conn.commit()
        # Seed default configuration if empty
        cursor = conn.cursor()
        cursor.execute("SELECT COUNT(*) FROM periods")
        if cursor.fetchone()[0] == 0:
            days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']
            slots = ['09:00 AM - 10:00 AM', '10:00 AM - 11:00 AM', '11:15 AM - 12:15 PM', '01:15 PM - 02:15 PM', '02:15 PM - 03:15 PM']
            for d in days:
                for s in slots:
                    conn.execute("INSERT INTO periods (day, time_slot) VALUES (?, ?)", (d, s))
            conn.commit()

init_db()

@app.route('/')
def index():
    return render_template('portal.html')

@app.route('/timetables')
def timetables():
    return render_template('public.html')

@app.route('/admin-login', methods=['GET', 'POST'])
def admin_login():
    if session.get('is_admin'):
        return redirect(url_for('admin_dashboard'))

    error = None
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        configured_username = os.environ.get('ADMIN_USERNAME')
        configured_hash = os.environ.get('ADMIN_PASSWORD_HASH')

        if (configured_username and configured_hash and
                username == configured_username and check_password_hash(configured_hash, password)):
            session.clear()
            session['is_admin'] = True
            session['admin_username'] = username
            return redirect(request.args.get('next') or url_for('admin_dashboard'))
        error = 'Invalid administrator credentials.'

    return render_template('admin-login.html', error=error)

@app.post('/admin-logout')
def admin_logout():
    session.clear()
    return redirect(url_for('index'))

@app.route('/admin')
@admin_required
def admin_dashboard():
    return render_template('index.html')

# --- Generic REST API helpers ---
def handle_crud(table, request):
    conn = get_db()
    cursor = conn.cursor()
    if request.method == 'GET':
        rows = cursor.execute(f"SELECT * FROM {table}").fetchall()
        return jsonify([dict(row) for row in rows])
    elif request.method == 'POST':
        data = request.json
        keys = list(data.keys())
        values = list(data.values())
        cols = ", ".join(keys)
        placeholders = ", ".join(["?" for _ in keys])
        cursor.execute(f"INSERT INTO {table} ({cols}) VALUES ({placeholders})", values)
        conn.commit()
        return jsonify({"status": "success", "id": cursor.lastrowid})
    elif request.method == 'PUT':
        data = request.json
        item_id = data.get('id')
        set_clause = ", ".join([f"{k} = ?" for k in data.keys() if k != 'id'])
        values = [v for k, v in data.items() if k != 'id'] + [item_id]
        cursor.execute(f"UPDATE {table} SET {set_clause} WHERE id = ?", values)
        conn.commit()
        return jsonify({"status": "updated"})
    elif request.method == 'DELETE':
        item_id = request.args.get('id')
        cursor.execute(f"DELETE FROM {table} WHERE id = ?", (item_id,))
        conn.commit()
        return jsonify({"status": "deleted"})

@app.route('/api/departments', methods=['GET', 'POST', 'PUT', 'DELETE'])
@admin_required
def manage_departments(): return handle_crud('departments', request)

@app.route('/api/sections', methods=['GET', 'POST', 'PUT', 'DELETE'])
@admin_required
def manage_sections(): return handle_crud('sections', request)

@app.route('/api/subjects', methods=['GET', 'POST', 'PUT', 'DELETE'])
@admin_required
def manage_subjects(): return handle_crud('subjects', request)

@app.route('/api/faculty', methods=['GET', 'POST', 'PUT', 'DELETE'])
@admin_required
def manage_faculty(): return handle_crud('faculty', request)

@app.route('/api/classrooms', methods=['GET', 'POST', 'PUT', 'DELETE'])
@admin_required
def manage_classrooms(): return handle_crud('classrooms', request)

@app.route('/api/periods', methods=['GET'])
def get_periods(): return handle_crud('periods', request)

@app.route('/api/timetable', methods=['GET'])
def get_timetable():
    conn = get_db()
    query = '''
        SELECT t.id, s.name as section_name, s.id as section_id, 
               sub.name as subject_name, sub.id as subject_id, sub.is_lab,
               f.name as faculty_name, f.id as faculty_id,
               c.name as classroom_name, c.id as classroom_id,
               p.day, p.time_slot, p.id as period_id
        FROM timetable t
        JOIN sections s ON t.section_id = s.id
        JOIN subjects sub ON t.subject_id = sub.id
        JOIN faculty f ON t.faculty_id = f.id
        JOIN classrooms c ON t.classroom_id = c.id
        JOIN periods p ON t.period_id = p.id
    '''
    rows = conn.execute(query).fetchall()
    return jsonify([dict(r) for r in rows])

@app.route('/api/public-timetable', methods=['GET'])
def get_public_timetable():
    conn = get_db()
    departments = [dict(row) for row in conn.execute('SELECT id, name FROM departments ORDER BY name')]
    sections = [dict(row) for row in conn.execute('SELECT id, name, department_id FROM sections ORDER BY name')]
    faculty = [dict(row) for row in conn.execute('SELECT id, name FROM faculty ORDER BY name')]
    periods = [dict(row) for row in conn.execute('SELECT id, day, time_slot FROM periods ORDER BY id')]
    timetable = [dict(row) for row in conn.execute('''
        SELECT t.id, s.id AS section_id, s.name AS section_name,
               s.department_id, sub.name AS subject_name,
               f.id AS faculty_id, f.name AS faculty_name,
               c.name AS classroom_name, p.day, p.time_slot
        FROM timetable t
        JOIN sections s ON t.section_id = s.id
        JOIN subjects sub ON t.subject_id = sub.id
        JOIN faculty f ON t.faculty_id = f.id
        JOIN classrooms c ON t.classroom_id = c.id
        JOIN periods p ON t.period_id = p.id
        ORDER BY p.id, s.name
    ''')]
    return jsonify({
        'departments': departments,
        'sections': sections,
        'faculty': faculty,
        'periods': periods,
        'timetable': timetable,
    })

# --- AI Constraint-Satisfaction Optimization Engine ---
@app.route('/api/generate-ai-timetable', methods=['POST'])
@admin_required
def generate_ai_timetable():
    conn = get_db()
    cursor = conn.cursor()
    
    sections = cursor.execute("SELECT * FROM sections").fetchall()
    subjects = cursor.execute("SELECT * FROM subjects").fetchall()
    faculty = cursor.execute("SELECT * FROM faculty").fetchall()
    classrooms = cursor.execute("SELECT * FROM classrooms").fetchall()
    periods = cursor.execute("SELECT * FROM periods").fetchall()

    if not sections or not subjects or not faculty or not classrooms:
        return jsonify({"status": "error", "message": "Incomplete data! Add departments, subjects, faculty, and classrooms first."}), 400

    # Clear existing schedule
    cursor.execute("DELETE FROM timetable")
    conn.commit()

    scheduled_count = 0
    conflicts_detected = 0
    assigned_slots = set() # Track (faculty_id, period_id) and (classroom_id, period_id) and (section_id, period_id)

    # Build work requirements queue
    allocation_queue = []
    for sec in sections:
        sec_subs = [sub for sub in subjects if sub['department_id'] == sec['department_id']]
        for sub in sec_subs:
            for _ in range(sub['hours_per_week']):
                allocation_queue.append((sec, sub))

    random.shuffle(allocation_queue)

    for sec, sub in allocation_queue:
        # Find matching faculty in the same department
        available_facs = [f for f in faculty if f['department_id'] == sec['department_id'] and f['subject_id'] == sub['id']]
        if not available_facs:
            available_facs = [f for f in faculty if f['department_id'] == sec['department_id'] and f['subject_id'] is None]
        if not available_facs:
            available_facs = [f for f in faculty if f['department_id'] == sec['department_id']]
        if not available_facs:
            available_facs = faculty # Fallback
        fac = random.choice(available_facs)

        # Find matching room (Lab vs Normal Classroom)
        matching_rooms = [c for c in classrooms if c['is_lab'] == sub['is_lab']]
        if not matching_rooms:
            matching_rooms = classrooms
        room = random.choice(matching_rooms)

        # Find an open period avoiding conflicts
        valid_periods = []
        for p in periods:
            if (fac['id'], p['id']) not in assigned_slots and \
               (room['id'], p['id']) not in assigned_slots and \
               (sec['id'], p['id']) not in assigned_slots:
                valid_periods.append(p)

        if valid_periods:
            chosen_period = random.choice(valid_periods)
            assigned_slots.add((fac['id'], chosen_period['id']))
            assigned_slots.add((room['id'], chosen_period['id']))
            assigned_slots.add((sec['id'], chosen_period['id']))

            cursor.execute('''
                INSERT INTO timetable (section_id, subject_id, faculty_id, classroom_id, period_id)
                VALUES (?, ?, ?, ?, ?)
            ''', (sec['id'], sub['id'], fac['id'], room['id'], chosen_period['id']))
            scheduled_count += 1
        else:
            conflicts_detected += 1

    conn.commit()

    # Calculate optimization score
    total_requested = len(allocation_queue)
    score = int((scheduled_count / total_requested) * 100) if total_requested > 0 else 100

    suggestions = []
    if conflicts_detected > 0:
        suggestions.append(f"Detected {conflicts_detected} unassigned lectures due to tight resource contention. Consider adding more Classrooms or Faculty members.")
    else:
        suggestions.append("All constraints successfully resolved with optimal room and faculty distribution!")

    return jsonify({
        "status": "success",
        "score": score,
        "scheduled_count": scheduled_count,
        "conflicts_detected": conflicts_detected,
        "suggestions": suggestions
    })

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port, debug=False)