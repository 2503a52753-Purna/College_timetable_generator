# College Timetable System

## Run locally

```powershell
python -m pip install -r requirements.txt
python app.py
```

Open <http://127.0.0.1:5000> in a browser. Other devices on the same network can use the computer's local IP address, for example `http://192.168.1.20:5000`.

## Admin authentication

The app uses Flask server-side sessions. The public timetable is available at `/`; management is protected at `/admin` and `/api/*` write routes. Configure a strong secret and a Werkzeug password hash before starting the server:

```powershell
$env:SECRET_KEY = 'replace-with-a-long-random-value'
$env:ADMIN_USERNAME = 'admin'
$env:ADMIN_PASSWORD_HASH = 'paste-a-werkzeug-generated-password-hash'
python -c "from werkzeug.security import generate_password_hash; print(generate_password_hash('replace-with-your-password'))"
```

Set `SESSION_COOKIE_SECURE=1` when serving over HTTPS. Do not commit credentials or the generated hash to source control.

## Publish on the internet

1. Create a repository containing this project folder.
2. Create a free Web Service on [Render](https://render.com) and connect the repository.
3. Render will use `render.yaml`, install the requirements, generate `SECRET_KEY`, and start the app with Gunicorn.
4. In the Render service environment settings, set `ADMIN_PASSWORD_HASH` to the output of `generate_password_hash` shown above.
5. Share the HTTPS URL Render provides.

The application currently uses SQLite, so its data is intended for demos and small deployments. Use a hosted database before relying on it for permanent production data.